import pickle
from preprocessing import *
from models_definition import *
import metrics
rf = RandomForestRegressor(n_estimators=50, max_features=3, max_depth=4, n_jobs=-1, random_state=1)
rf.fit(X_train_cut,y_train_cut)

filename = "../../models/modelentraine_rf.pickle"
with open(filename, 'wb') as file:
    pickle.dump(rf, file)
