from sklearn.preprocessing import PolynomialFeatures
from sklearn.ensemble import RandomForestRegressor
from sklearn.svm import SVR
from sklearn import linear_model
from sklearn.linear_model import SGDRegressor
from sklearn import metrics
import numpy as np
from preprocessing import *

def metricss(ytest,predicttest):
   mse = metrics.mean_squared_error(ytest,predicttest)
   print('RMSE test_data : ',np.sqrt(mse))
   print('R_2 test_data  : ',metrics.r2_score(ytest,predicttest))

def linear_m(X_train,y_train,X_test,y_test):
    lm = linear_model.LinearRegression()
    lm.fit(X_train,y_train)
    predict_test=lm.predict(X_test)
    metricss(y_test,predict_test)

#polynomial model
def poly_m(X_train,y_train,X_test,y_test):
    poly = PolynomialFeatures(degree=2)
    X_train_poly = poly.fit_transform(X_train)
    X_test_poly = poly.fit_transform(X_test)
    polyreg = linear_model.LinearRegression()
    polyreg.fit(X_train_poly, y_train)
    y_test_predict = polyreg.predict(X_test_poly)
    metricss(y_test,y_test_predict)

#random forest model
def random_f(X_train,y_train,X_test,y_test):
    rf = RandomForestRegressor(n_estimators=50, max_features=3, max_depth=4, n_jobs=-1, random_state=1)
    rf.fit(X_train, y_train)
    y_test_predict = rf.predict(X_test)
    metricss(y_test,y_test_predict)

#Support vector regressor model
def support_v(X_train,y_train,X_test,y_test):
    regressor = SVR(kernel = 'linear')
    regressor.fit(X_train,y_train)
    y_test_predict = regressor.predict(X_test)
    metricss(y_test,y_test_predict)
