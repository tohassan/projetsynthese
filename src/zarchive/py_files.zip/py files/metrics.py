from models_definition import *

print('================== metrics without clip ==================================')
print("Linear model: -------------------------")
linear_m(X_train,y_train,X_test,y_test)
print("polynomial model: ---------------------")
poly_m(X_train,y_train,X_test,y_test)
print("random_f: -----------------------------")
random_f(X_train,y_train,X_test,y_test)
print("support vect: -------------------------")
support_v(X_train,y_train,X_test,y_test)

print('================== metrics with clip =====================================')

print("Linear model: -------------------------")
linear_m(X_train_cut,y_train_cut,X_test_cut,y_test_cut)
print("polynomial model: ---------------------")
poly_m(X_train_cut,y_train_cut,X_test_cut,y_test_cut)
print("random_f: -----------------------------")
random_f(X_train_cut,y_train_cut,X_test_cut,y_test_cut)
print("support vect: -------------------------")
support_v(X_train_cut,y_train_cut,X_test_cut,y_test_cut)